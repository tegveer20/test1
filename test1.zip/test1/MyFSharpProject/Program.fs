﻿open System

// Salaries list
let salaries = [75000.0; 48000.0; 120000.0; 190000.0; 300113.0; 92000.0; 36000.0]

// High-income salaries (above $100,000)(filtering saleries)
let highIncomeSalaries = 
    salaries |> List.filter (fun salary -> salary > 100000.0)

// Function to calculate tax based on the provided table
let calculateTax salary =
    match salary with
    | s when s <= 49020.0 -> s * 0.15 // this 15% is tax
    | s when s <= 98040.0 -> s * 0.205
    | s when s <= 151978.0 -> s * 0.26
    | s when s <= 216511.0 -> s * 0.29
    | _ -> salary * 0.33

// Map function to calculate tax for all salaries
let taxes = salaries |> List.map calculateTax

// Filter and increment salaries less than $49,020 by $20,000
let incrementedSalaries = 
    salaries 
    |> List.map (fun salary -> if salary < 49020.0 then salary + 20000.0 else salary)

// Filter salaries between $50,000 and $100,000 and sum them
let filteredSum =
    salaries 
    |> List.filter (fun salary -> salary >= 50000.0 && salary <= 100000.0)
    |> List.reduce (+)

// Print results
printfn "High-income salaries: %A" highIncomeSalaries
printfn "Taxes for all salaries: %A" taxes
printfn "Salaries incremented: %A" incrementedSalaries
printfn "Sum of salaries between $50,000 and $100,000: %f" filteredSum

// Tail-recursive function to calculate the sum of all multiples of 3 up to a given number
let sumOfMultiplesOf3 n =
    let rec helper acc current =
        if current = 0 then acc
        else helper (acc + current) (current - 3)
    helper 0 n

// Example usage of the tail-recursive function
let result = sumOfMultiplesOf3 27
printfn "Sum of multiples of 3 up to 27: %d" result

[<EntryPoint>]
let main argv =
    0 // Return 0 to indicate the program ran successfullyss